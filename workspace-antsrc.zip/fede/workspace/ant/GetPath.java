package fede.workspace.ant;

import java.io.File;
import java.util.Set;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.types.Path;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.JavaCore;

import fede.v6.melusine.core.MelusineCore;
import fede.workspace.domain.Item;
import fede.workspace.domain.WorkspaceDomain;
import fede.workspace.eclipse.java.JavaProjectManager;
import fede.workspace.tool.view.WSPlugin;

public class GetPath extends Path {
	IProject eproject;
	public GetPath(Project p) {
		super(p);
	}
	
	public void setItem(String itemId) {
		log("item : "+itemId);
		WorkspaceDomain wd = (WorkspaceDomain) MelusineCore.getDomainRoot(WorkspaceDomain.DOMAIN_NAME);
		Item item = wd.getCurrentModel().getItem(itemId);
		
		
		try {
			eproject	= WSPlugin.getProjectFromItem(item);
			Set<IClasspathEntry> itemjavapath = JavaProjectManager.calculateDependencies(item);
			for (IClasspathEntry entry : itemjavapath) {
				if (entry.getEntryKind() == IClasspathEntry.CPE_PROJECT) {
					addProjectClasspath(entry);
				} else if (entry.getEntryKind() == IClasspathEntry.CPE_LIBRARY) {
					addLibClasspath(entry);
				}
			}
		} catch (CoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void addLibClasspath(IClasspathEntry entry) {
		File f = entry.getPath().toFile();
		add(new Path(getProject(),f.getAbsolutePath()));
	}

	private void addProjectClasspath(IClasspathEntry entry) {
		JavaCore.getResolvedClasspathEntry(entry);
	}
	
	

}
