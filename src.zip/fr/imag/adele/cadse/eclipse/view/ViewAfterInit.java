package fr.imag.adele.cadse.eclipse.view;

public interface ViewAfterInit {

	public void afterInit();
}
