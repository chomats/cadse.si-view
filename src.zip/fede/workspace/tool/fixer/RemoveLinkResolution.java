/* 
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package fede.workspace.tool.fixer;

import org.eclipse.core.resources.IMarker;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMarkerResolution2;

import fr.imag.adele.cadse.core.CadseException;
import fr.imag.adele.cadse.core.Item;
import fr.imag.adele.cadse.core.Link;

public class RemoveLinkResolution implements IMarkerResolution2 {

	private final Link 	link;
	
	public RemoveLinkResolution(Link link) {
		this.link	= link;
	}
	
	public String getDescription() {
		return getLabel();
	}

	public Image getImage() {
		return null;
	}

	public String getLabel() {
		String label = "delete "+link.getDestinationId()+" from "+link.getLinkType().getName()+" of "+link.getSourceId();
		return label;
	}

	public void run(IMarker marker) {
        try {
        	link.delete();
        } catch (CadseException e) {
            e.printStackTrace();
        }
	}

}
