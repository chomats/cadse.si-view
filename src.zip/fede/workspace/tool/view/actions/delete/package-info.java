

@PackageInfo(version="1.0.0", requirePackages={})
package fede.workspace.tool.view.actions.delete;

import fr.imag.adele.packageinfo.PackageInfo;
